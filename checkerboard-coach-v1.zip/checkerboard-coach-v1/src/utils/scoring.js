export function levelWindowText(level) {
  if (level <= 3) return 'Levels 1–3: challenge is banked. Player can convert later in the rally.';
  if (level === 4) return 'Level 4: after the challenge, player must win within 4 shots or reset the challenge.';
  return 'Level 5: after the challenge, player must win within 2 shots or reset the challenge.';
}

export function scoreRally(event, level = 1) {
  let total = 0;
  const parts = [];

  if (event.win) { total += 1; parts.push('rally win +1'); }

  if (event.challenge === 'single') { total += 1; parts.push('single +1'); }
  if (event.challenge === 'pair') { total += 2; parts.push('pair +2'); }
  if (event.challenge === 'triple') { total += 3; parts.push('triple +3'); }

  if (event.afterChallenge) { total += 3; parts.push('win-after-challenge bonus +3'); }
  if (event.clean) { total += 2; parts.push('clean winner +2'); }

  return {
    total,
    label: parts.join(' · ') || 'no score',
    level
  };
}
